# CO2-rSO2 Tables and Figures Draft

Date: 2026-06-08

This file translates current repository outputs into manuscript display items. It should be revised after sensitivity analyses and final journal formatting are finalized.

Generated manuscript assets are stored under `generated_assets/`.

## Main Table 1: cohort characteristics

Status: generated from the local CO2 Table 1/2 workbook.

Generated files:

- `generated_assets/table1_cohort_characteristics.csv`
- `generated_assets/table1_cohort_characteristics.xlsx`

Source:

- `results/manuscript_tables/table1_2_co2_rso2_wide.csv`
- `results/manuscript_tables/table1_2_co2_rso2_flow_counts.csv`

Content:

- channel-specific patient counts;
- final usable timestamp-level observations;
- selected baseline demographics and comorbidities;
- baseline hemoglobin, cardiac index, and mean blood pressure;
- intraoperative EtCO2, FiO2, temperature, MAP, cardiac index, and tissue oxygenation summaries.

Table note:

- `SEX=1` is reported as `Male, n (%)` in manuscript-facing generated assets; see `CO2_SEX_LABEL_AUDIT.md`.

Full supplementary eTable 1/2:

- `generated_assets/supplementary_etable1_2_cohort_characteristics.xlsx`
- `generated_assets/supplementary_etable1_2_cohort_characteristics_long.csv`

## Main Table 2: clinical-step adjusted contrasts

Candidate table title:

Adjusted changes in tissue oxygenation associated with clinically interpretable intraoperative exposure increments

| Outcome channel | Exposure | Clinical increment | Adjusted rSO2 difference, percentage points | 95% CI | Interpretation |
|---|---:|---:|---:|---:|---|
| rSO2_Ch1 | EtCO2 | +5 mmHg | +2.89 | +2.41 to +3.33 | strongest positive association |
| rSO2_Ch2 | EtCO2 | +5 mmHg | +2.98 | +2.64 to +3.28 | strongest positive association |
| SftO2 | EtCO2 | +5 mmHg | +0.92 | +0.68 to +1.16 | smaller positive association |
| rSO2_Ch1 | FiO2 | +10 percentage points | -0.18 | -0.49 to +0.12 | weak/inconsistent |
| rSO2_Ch2 | FiO2 | +10 percentage points | -0.05 | -0.46 to +0.37 | weak/inconsistent |
| SftO2 | FiO2 | +10 percentage points | +0.30 | +0.11 to +0.46 | small positive association |
| rSO2_Ch1 | Temperature | +0.5 C | +0.10 | -0.16 to +0.35 | weak/inconsistent |
| rSO2_Ch2 | Temperature | +0.5 C | +0.55 | +0.25 to +0.87 | modest positive association |
| SftO2 | Temperature | +0.5 C | +0.15 | -0.03 to +0.30 | weak/inconsistent |

Source:

- `code/analysis_bundle/output/tables/crossvar_effect_summary.csv`
- current run: `n10000_overall_mapci_te_boot200`

Generated files:

- `generated_assets/table2_clinical_step_contrasts.csv`
- `generated_assets/table2_clinical_step_contrasts.xlsx`

Manuscript note:

- Use "adjusted difference" or "associated with", not "effect" in prose unless causal language is explicitly justified.

## Supplementary Table: model diagnostics

Candidate table title:

Generalized additive model performance and EtCO2 smooth-term diagnostics

| Outcome channel | Sampled observations | Model features | Effective DOF | Deviance explained | EtCO2 smooth EDF | EtCO2 smooth p value |
|---|---:|---:|---:|---:|---:|---:|
| rSO2_Ch1 | 100,000 | 17 | 51.14 | 0.232 | 8.42 | <0.001 |
| rSO2_Ch2 | 100,000 | 17 | 51.21 | 0.219 | 8.43 | <0.001 |
| SftO2 | 100,000 | 18 | 52.22 | 0.154 | 8.45 | <0.001 |

Sources:

- `results/supplemental_etables/supplemental_etable6_model_performance_co2_rso2.csv`
- `results/supplemental_etables/supplemental_etable7_nonparametric_terms_co2_rso2.csv`

Generated files:

- `generated_assets/supplementary_model_diagnostics.csv`
- `generated_assets/supplementary_model_diagnostics.xlsx`

## Figure 1: cohort and distributions

Status: generated as a cohort-flow figure.

Generated clean figure:

- `generated_assets/figure1_cohort_flow.png`
- `generated_assets/source_data_figure1_cohort_flow.csv`

Source:

- `results/manuscript_tables/table1_2_co2_rso2_flow_counts.csv`

Legend draft:

Figure 1. Cohort assembly by tissue oxygenation channel. Bars show timestamp-level rows retained at each filtering step, and labels show the corresponding number of patients. The final analytic rows were 20,021,703 for left SctO2, 20,075,597 for right SctO2, and 20,068,759 for SftO2.

## Figure 2: adjusted EtCO2-rSO2 curves

Status: strongest main figure candidate, but should be remade.

Recommended panels:

- Three horizontally aligned panels, one per outcome channel.
- X-axis: EtCO2, mmHg.
- Y-axis: adjusted rSO2, percentage.
- Show bootstrap 95% CI bands.
- Mark clinically relevant EtCO2 values, for example 35 and 40 mmHg, if justified.
- Add observed EtCO2 density or bin counts when available from the analytic dataset. The current generated figure only shows modeled curve support ticks and should not be described as a histogram.

Current source:

- EtCO2 panels from `code/analysis_bundle/output/figures/figure_C_threshold_turning.png`

Generated clean figure:

- `generated_assets/figure2_etco2_adjusted_curves.png`
- `generated_assets/figure2_etco2_adjusted_curves.svg`
- `generated_assets/source_data_figure2_etco2_curves.csv`

Required cleanup:

- Remove missing MAP/SV/HR/RRtotal/TVinsp/Pmean panels.
- Use final clinical labels: `Left SctO2`, `Right SctO2`, and `SftO2`.

## Figure 3: clinical-step contrasts

Status: usable concept, needs cleanup.

Recommended panels:

- Either one grouped bar plot with outcome channel as color/facet and exposure as x-axis, or three channel-specific panels.
- Include only EtCO2, FiO2, and temperature unless the missing all-intraop comparisons are completed.

Current source:

- `code/analysis_bundle/output/figures/figure_A_delta_bar.png`
- `code/analysis_bundle/output/figures/figure_A_delta_bar_all_intraop_n10000_mapci_te.png`

Generated clean figure:

- `generated_assets/figure3_clinical_step_contrasts.png`
- `generated_assets/figure3_clinical_step_contrasts.svg`
- `generated_assets/source_data_figure3_clinical_step.csv`

Required cleanup:

- Remove variables marked missing.
- Use human-readable labels: EtCO2, FiO2, Temperature.
- Make uncertainty intervals visible at publication scale.

## Supplementary Figure 1: local slope interpretation

Status: generated as an optional EtCO2-focused supplementary figure.

The local slope heatmap is avoided in the main package because it is too abstract for a clinical journal. The generated supplementary figure is a simple EtCO2-only local-slope plot by actual EtCO2 mmHg bins from 20 to 50 mmHg.

Generated clean figure:

- `generated_assets/figure4_etco2_local_slopes.png`
- `generated_assets/source_data_figure4_etco2_local_slopes.csv`

Source:

- `generated_assets/source_data_figure2_etco2_curves.csv`; local slopes are finite-difference summaries of the adjusted EtCO2 response curves

Legend draft:

Supplementary Figure 1. Local EtCO2-rSO2 slopes across the analytic EtCO2 range. Lines show descriptive mean local slopes from EtCO2 mmHg bins for each tissue oxygenation channel. Left and right SctO2 showed the largest slopes in the mid-range bins, whereas SftO2 showed a smaller and gradually declining slope. These slopes are model-shape summaries and should not be interpreted as causal effects of changing EtCO2 or as treatment thresholds.

## Figure legend draft for Figure 2

Adjusted relationship between end-tidal carbon dioxide and regional tissue oxygenation. Generalized additive models estimated adjusted rSO2 across the observed EtCO2 range for each oxygenation channel. Solid lines show model-estimated mean rSO2 and shaded bands show bootstrap 95% confidence intervals. Models adjusted for FiO2, temperature, mean arterial pressure, hemodynamic covariates, and patient-level factors. EtCO2, end-tidal carbon dioxide; rSO2, regional tissue oxygen saturation.

## Figure legend draft for Figure 3

Adjusted tissue oxygenation differences associated with clinically interpretable intraoperative exposure increments. Bars show the estimated rSO2 difference for a 5 mmHg higher EtCO2, 10 percentage-point higher FiO2, or 0.5 C higher temperature. Error bars show bootstrap 95% confidence intervals. Comparisons are associative and do not imply causal effects of changing ventilation or temperature.
