# CO2-rSO2 Manuscript Development Package Manifest

Build date: 2026-06-09
Git branch: master
Git commit: 2b8d3ba
Working tree dirty at build: no

Status: manuscript-development package, not final submission-ready.

Remaining gates before final journal submission:

- Confirm author list, ethics, funding, competing interests, data availability, code availability, contributions, and acknowledgements.
- Decide whether to run and report the planned 5-model sensitivity analysis package.
- Apply target-journal figure sizing, reference styling, and source-data upload conventions.
- Complete rendered DOCX page-level visual QA.

## Included Files

| Package path | Repository source | Size, bytes | SHA-256 prefix |
| --- | --- | ---: | --- |
| `main/CO2_MANUSCRIPT_DRAFT_V1.docx` | `docs/manuscript_development/CO2_MANUSCRIPT_DRAFT_V1.docx` | 45807 | `5be155f49998` |
| `main/CO2_MANUSCRIPT_DRAFT_V1.md` | `docs/manuscript_development/CO2_MANUSCRIPT_DRAFT_V1.md` | 24438 | `9a08c1583bcd` |
| `supplement/CO2_SUPPLEMENTARY_METHODS_DRAFT.docx` | `docs/manuscript_development/CO2_SUPPLEMENTARY_METHODS_DRAFT.docx` | 41785 | `2f63eea91de5` |
| `supplement/CO2_SUPPLEMENTARY_METHODS_DRAFT.md` | `docs/manuscript_development/CO2_SUPPLEMENTARY_METHODS_DRAFT.md` | 9474 | `6bc5d05c76f9` |
| `supplement/CO2_SUPPLEMENTARY_TABLES_INDEX.docx` | `docs/manuscript_development/CO2_SUPPLEMENTARY_TABLES_INDEX.docx` | 38963 | `57342ca749e5` |
| `supplement/CO2_SUPPLEMENTARY_TABLES_INDEX.md` | `docs/manuscript_development/CO2_SUPPLEMENTARY_TABLES_INDEX.md` | 3326 | `2222f7805579` |
| `tables/table1_cohort_characteristics.csv` | `docs/manuscript_development/generated_assets/table1_cohort_characteristics.csv` | 1228 | `67006d7521aa` |
| `tables/table1_cohort_characteristics.xlsx` | `docs/manuscript_development/generated_assets/table1_cohort_characteristics.xlsx` | 5676 | `88b72cc2c9e5` |
| `tables/table2_clinical_step_contrasts.csv` | `docs/manuscript_development/generated_assets/table2_clinical_step_contrasts.csv` | 545 | `e40da8fce52f` |
| `tables/table2_clinical_step_contrasts.xlsx` | `docs/manuscript_development/generated_assets/table2_clinical_step_contrasts.xlsx` | 5248 | `22d61c948077` |
| `tables/supplementary_etable1_2_cohort_characteristics.xlsx` | `docs/manuscript_development/generated_assets/supplementary_etable1_2_cohort_characteristics.xlsx` | 13367 | `434e603539b1` |
| `tables/supplementary_etable1_2_cohort_characteristics_long.csv` | `docs/manuscript_development/generated_assets/supplementary_etable1_2_cohort_characteristics_long.csv` | 12238 | `281b24e6e590` |
| `tables/supplementary_model_diagnostics.csv` | `docs/manuscript_development/generated_assets/supplementary_model_diagnostics.csv` | 261 | `0463f2538917` |
| `tables/supplementary_model_diagnostics.xlsx` | `docs/manuscript_development/generated_assets/supplementary_model_diagnostics.xlsx` | 5096 | `e012f2c600ee` |
| `tables/table1_2_co2_rso2.xlsx` | `results/manuscript_tables/table1_2_co2_rso2.xlsx` | 13442 | `4795ce83a495` |
| `tables/table1_2_co2_rso2_flow_counts.csv` | `results/manuscript_tables/table1_2_co2_rso2_flow_counts.csv` | 1031 | `41805c86d835` |
| `tables/table1_2_co2_rso2_long.csv` | `results/manuscript_tables/table1_2_co2_rso2_long.csv` | 12075 | `b85f6129634f` |
| `tables/table1_2_co2_rso2_wide.csv` | `results/manuscript_tables/table1_2_co2_rso2_wide.csv` | 5795 | `a1f704288a7f` |
| `tables/supplemental_etable3_artifact_co2_rso2.csv` | `results/supplemental_etables/supplemental_etable3_artifact_co2_rso2.csv` | 2786 | `eea055cda1f8` |
| `tables/supplemental_etable4_missingness_imputation_other_intraop.csv` | `results/supplemental_etables/supplemental_etable4_missingness_imputation_other_intraop.csv` | 3191 | `93e68fd2ca42` |
| `tables/supplemental_etable5_patient_level_co2_rso2.csv` | `results/supplemental_etables/supplemental_etable5_patient_level_co2_rso2.csv` | 555 | `39e16103822f` |
| `tables/supplemental_etable6_model_performance_co2_rso2.csv` | `results/supplemental_etables/supplemental_etable6_model_performance_co2_rso2.csv` | 6714 | `40e77837c43a` |
| `tables/supplemental_etable7_nonparametric_terms_co2_rso2.csv` | `results/supplemental_etables/supplemental_etable7_nonparametric_terms_co2_rso2.csv` | 5611 | `82794d5b8f5f` |
| `tables/supplemental_etable8_parametric_terms_co2_rso2.csv` | `results/supplemental_etables/supplemental_etable8_parametric_terms_co2_rso2.csv` | 3883 | `27130be8ba69` |
| `tables/Supplemental_eTables3_5_CO2_rSO2.xlsx` | `results/supplemental_etables/Supplemental_eTables3_5_CO2_rSO2.xlsx` | 10954 | `0c175e523400` |
| `tables/Supplemental_eTables6_8_CO2_rSO2.xlsx` | `results/supplemental_etables/Supplemental_eTables6_8_CO2_rSO2.xlsx` | 9540 | `d06abe287d4f` |
| `figures/figure1_cohort_flow.png` | `docs/manuscript_development/generated_assets/figure1_cohort_flow.png` | 105423 | `aab01da7b764` |
| `figures/figure2_etco2_adjusted_curves.png` | `docs/manuscript_development/generated_assets/figure2_etco2_adjusted_curves.png` | 92330 | `45e2fe0df0cc` |
| `figures/figure2_etco2_adjusted_curves.svg` | `docs/manuscript_development/generated_assets/figure2_etco2_adjusted_curves.svg` | 30126 | `1f39236f7688` |
| `figures/figure3_clinical_step_contrasts.png` | `docs/manuscript_development/generated_assets/figure3_clinical_step_contrasts.png` | 39104 | `ea3cbe660c97` |
| `figures/figure3_clinical_step_contrasts.svg` | `docs/manuscript_development/generated_assets/figure3_clinical_step_contrasts.svg` | 8143 | `2b3fbd7df35f` |
| `figures/figure4_etco2_local_slopes.png` | `docs/manuscript_development/generated_assets/figure4_etco2_local_slopes.png` | 75530 | `4f07dae67a81` |
| `source_data/source_data_figure1_cohort_flow.csv` | `docs/manuscript_development/generated_assets/source_data_figure1_cohort_flow.csv` | 592 | `4bc1308b5272` |
| `source_data/source_data_figure2_etco2_curves.csv` | `docs/manuscript_development/generated_assets/source_data_figure2_etco2_curves.csv` | 67756 | `735befbfe5f7` |
| `source_data/source_data_figure3_clinical_step.csv` | `docs/manuscript_development/generated_assets/source_data_figure3_clinical_step.csv` | 545 | `e40da8fce52f` |
| `source_data/source_data_figure4_etco2_local_slopes.csv` | `docs/manuscript_development/generated_assets/source_data_figure4_etco2_local_slopes.csv` | 816 | `1b996220fe20` |
| `documentation/README.md` | `docs/manuscript_development/README.md` | 5945 | `c003b7423d4e` |
| `documentation/CO2_SUBMISSION_GAP_CHECKLIST.md` | `docs/manuscript_development/CO2_SUBMISSION_GAP_CHECKLIST.md` | 4651 | `b8fc03dedc7e` |
| `documentation/CO2_TABLES_AND_FIGURES_DRAFT.md` | `docs/manuscript_development/CO2_TABLES_AND_FIGURES_DRAFT.md` | 7765 | `47888029f962` |
| `documentation/CO2_TABLE1_2_HPC_RUN_LOG.md` | `docs/manuscript_development/CO2_TABLE1_2_HPC_RUN_LOG.md` | 3473 | `ae59c3d8ab6c` |
| `documentation/CO2_TABLE1_EXTRACTION_SPEC.md` | `docs/manuscript_development/CO2_TABLE1_EXTRACTION_SPEC.md` | 5959 | `1a2edfefda70` |
| `documentation/CO2_CHANNEL_NAMING_AUDIT.md` | `docs/manuscript_development/CO2_CHANNEL_NAMING_AUDIT.md` | 4921 | `c0a4d9381bd2` |
| `documentation/CO2_SEX_LABEL_AUDIT.md` | `docs/manuscript_development/CO2_SEX_LABEL_AUDIT.md` | 1627 | `490abc9e9deb` |
| `documentation/CO2_SENSITIVITY_DECISION.md` | `docs/manuscript_development/CO2_SENSITIVITY_DECISION.md` | 1853 | `352e29840d04` |
| `documentation/CO2_AUTHOR_SUBMISSION_STATEMENTS_TEMPLATE.md` | `docs/manuscript_development/CO2_AUTHOR_SUBMISSION_STATEMENTS_TEMPLATE.md` | 4055 | `64bd7d9546e9` |
| `documentation/CO2_REFERENCE_AUDIT.md` | `docs/manuscript_development/CO2_REFERENCE_AUDIT.md` | 3148 | `7f2c3e4a6196` |
| `documentation/CO2_SOURCE_DATA_PACKAGE_INDEX.md` | `docs/manuscript_development/CO2_SOURCE_DATA_PACKAGE_INDEX.md` | 4139 | `46fda53347aa` |
| `documentation/CO2_LITERATURE_AND_POSITIONING.md` | `docs/manuscript_development/CO2_LITERATURE_AND_POSITIONING.md` | 4275 | `c32935adf589` |
| `documentation/CO2_MANUSCRIPT_BLUEPRINT.md` | `docs/manuscript_development/CO2_MANUSCRIPT_BLUEPRINT.md` | 9163 | `5fe905db76ed` |
| `documentation/CO2_PRIOR_MAPCI_FRAMEWORK_EXTRACT.md` | `docs/manuscript_development/CO2_PRIOR_MAPCI_FRAMEWORK_EXTRACT.md` | 4219 | `a4a76e003b21` |
| `documentation/CO2_10_ROUND_MANUSCRIPT_REVIEW_LOG.md` | `docs/manuscript_development/CO2_10_ROUND_MANUSCRIPT_REVIEW_LOG.md` | 4953 | `8b58f397c55a` |
